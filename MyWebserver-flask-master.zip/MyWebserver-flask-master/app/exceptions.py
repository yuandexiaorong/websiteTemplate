class ValidationError(ValueError):
    pass


class UserError(Exception):
    pass


class Warning(Exception):
    pass

